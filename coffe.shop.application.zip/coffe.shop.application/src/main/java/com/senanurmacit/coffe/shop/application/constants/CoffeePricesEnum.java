package com.senanurmacit.coffe.shop.application.constants;

import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@NoArgsConstructor
@Getter
public enum CoffeePricesEnum {
    ESPRESSO(1, 7.0, espressoContent()),
    DOUBLE_ESPRESSO(2, 12.0, doubleEspressoContent()),
    CAPPUCCINO(3, 12.0, cappuccinoContent()),
    CAFFE_LATTE(4, 12.0, caffeLatteContent()),
    MOCHA(5, 13.0, mochaContent()),
    AMERICANO(6, 10.0, americanoContent()),
    HOT_WATER(7, 3.0, hotWaterContent());

    Double price;
    Integer number;
    Map<ContentTypesEnum, Integer> content;

    CoffeePricesEnum(Integer number, Double price, Map<ContentTypesEnum, Integer> content) {
        this.number = number;
        this.price = price;
        this.content = content;
    }

    CoffeePricesEnum(Integer number) {
        this.number = number;
    }

    private static final Map<ContentTypesEnum, Integer> espressoContent() {
        Map<ContentTypesEnum, Integer> esspressoMapper = new HashMap<>();
        esspressoMapper.put(ContentTypesEnum.ESPRESSO, 1);
        return esspressoMapper;
    }

    private static final Map<ContentTypesEnum, Integer> doubleEspressoContent() {
        Map<ContentTypesEnum, Integer> esspressoMapper = new HashMap<>();
        esspressoMapper.put(ContentTypesEnum.ESPRESSO, 2);
        return esspressoMapper;
    }

    private static final Map<ContentTypesEnum, Integer> americanoContent() {
        Map<ContentTypesEnum, Integer> esspressoMapper = new HashMap<>();
        esspressoMapper.put(ContentTypesEnum.ESPRESSO, 1);
        esspressoMapper.put(ContentTypesEnum.HOT_WATER, 2);
        return esspressoMapper;
    }

    private static final Map<ContentTypesEnum, Integer> cappuccinoContent() {
        Map<ContentTypesEnum, Integer> esspressoMapper = new HashMap<>();
        esspressoMapper.put(ContentTypesEnum.ESPRESSO, 1);
        esspressoMapper.put(ContentTypesEnum.STEAMED_MILK, 2);
        esspressoMapper.put(ContentTypesEnum.MILK_FOAM, 2);
        return esspressoMapper;
    }

    private static final Map<ContentTypesEnum, Integer> caffeLatteContent() {
        Map<ContentTypesEnum, Integer> esspressoMapper = new HashMap<>();
        esspressoMapper.put(ContentTypesEnum.ESPRESSO, 1);
        esspressoMapper.put(ContentTypesEnum.STEAMED_MILK, 3);
        esspressoMapper.put(ContentTypesEnum.MILK_FOAM, 1);
        return esspressoMapper;
    }

    private static final Map<ContentTypesEnum, Integer> mochaContent() {
        Map<ContentTypesEnum, Integer> esspressoMapper = new HashMap<>();
        esspressoMapper.put(ContentTypesEnum.ESPRESSO, 1);
        esspressoMapper.put(ContentTypesEnum.STEAMED_MILK, 1);
        esspressoMapper.put(ContentTypesEnum.MILK_FOAM, 1);
        esspressoMapper.put(ContentTypesEnum.HOT_CHOCOLATE, 2);
        return esspressoMapper;
    }

    private static final Map<ContentTypesEnum, Integer> hotWaterContent() {
        Map<ContentTypesEnum, Integer> esspressoMapper = new HashMap<>();
        esspressoMapper.put(ContentTypesEnum.HOT_WATER, 1);
        return esspressoMapper;
    }

}
