package com.senanurmacit.coffe.shop.application.constants;

public enum CoffeeStatusEnum {
    READY,
    PREPARING,
    ORDERED;
}
