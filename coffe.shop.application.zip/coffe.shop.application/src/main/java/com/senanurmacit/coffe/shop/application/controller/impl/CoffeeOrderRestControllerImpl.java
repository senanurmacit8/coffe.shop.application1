package com.senanurmacit.coffe.shop.application.controller.impl;

import com.senanurmacit.coffe.shop.application.controller.CoffeeOrderRestController;
import com.senanurmacit.coffe.shop.application.service.CoffeeOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping({"/coffeeOrder"})
public class CoffeeOrderRestControllerImpl implements CoffeeOrderRestController {

    //Logger logger = (Logger) LoggerFactory.getLogger(CoffeeOrderRestControllerImpl.class);

    @Autowired
    private CoffeeOrderService coffeeOrderService;
/*
    @RequestMapping(value = "/coffeeOrder", method = RequestMethod.GET)
    @ResponseBody
    public List<CoffeeContentDTO> getAllCoffeeTypes() {
        coffeeOrderService.getAllCoffeeTypes();

        return Arrays.asList(new CoffeeContentDTO());
    }

 */

}
