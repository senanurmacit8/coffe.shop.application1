package com.senanurmacit.coffe.shop.application.service.impl;

import com.senanurmacit.coffe.shop.application.constants.CoffeePricesEnum;
import com.senanurmacit.coffe.shop.application.constants.CoffeeStatusEnum;
import com.senanurmacit.coffe.shop.application.constants.ContentTypesEnum;
import com.senanurmacit.coffe.shop.application.dto.coffee.CoffeePriceDTO;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Service
public class CoffeeOrderServiceImpl {

    public static void main(String[] args) throws Exception {

        CoffeePriceDTO coffeePriceDTO = new CoffeePriceDTO();
        Map<Integer, String> coffeeNumberandNameMapper = new HashMap<>();

        Arrays.stream(CoffeePricesEnum.values()).forEach(coffeePricesEnum -> {
            System.out.println(coffeePricesEnum.getNumber() + ". " + coffeePricesEnum.toString() + "(" + coffeePricesEnum.getPrice() + " ₺)");
            coffeeNumberandNameMapper.put(coffeePricesEnum.getNumber(), coffeePricesEnum.toString());
        });

        System.out.println("Lütfen içmek istediğiniz kahvenin numarasını giriniz : ");
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));
        String selectedNumber = reader.readLine();

        coffeePriceDTO.setStatus(CoffeeStatusEnum.ORDERED.toString());

        if (selectedNumber != null && Integer.valueOf(selectedNumber) > 0) {

            String selectedCoffeePricesEnum = coffeeNumberandNameMapper.get(Integer.valueOf(selectedNumber));
            coffeePriceDTO.setPrice(CoffeePricesEnum.valueOf(CoffeePricesEnum.class, selectedCoffeePricesEnum).getPrice());
            coffeePriceDTO.setCoffeeName(CoffeePricesEnum.valueOf(CoffeePricesEnum.class, selectedCoffeePricesEnum).toString());
            coffeePriceDTO.setContent(CoffeePricesEnum.valueOf(CoffeePricesEnum.class, selectedCoffeePricesEnum).getContent());
            coffeePriceDTO.setStatus(CoffeeStatusEnum.PREPARING.toString());
            prepareCoffee(coffeePriceDTO);
        }

        System.out.println("Teşekkürler kahveniz hazırlanıyor.");

        showCoffeeContent(coffeePriceDTO);


    }

    private static CoffeePriceDTO prepareCoffee(CoffeePriceDTO coffeePriceDTO) {
        if (checkAllStatements()) {
            coffeePriceDTO.setStatus(CoffeeStatusEnum.READY.toString());
        }
        return coffeePriceDTO;
    }

    //@Scheduled(cron = "*/5 * * * * ?")
    private static void showCoffeeContent(CoffeePriceDTO coffeePriceDTO) {
        if (CoffeeStatusEnum.READY.toString().equals(coffeePriceDTO.getStatus().toString())) {
            int hotWaterNum = 0;
            if (coffeePriceDTO.getContent().get(ContentTypesEnum.HOT_WATER) != null) {
                hotWaterNum = +coffeePriceDTO.getContent().get(ContentTypesEnum.HOT_WATER);
            }

            StringBuilder stringBuilder = new StringBuilder();

            StringBuilder message = new StringBuilder();
            message.append(coffeePriceDTO.getCoffeeName() + " seçtiniz.Bu içeceğimiz ");
            if (hotWaterNum != 0) {
                message.append(hotWaterNum + " doz sıcak su ");
            }
            coffeePriceDTO.getContent().forEach((contentTypesEnum, integer) -> message.append(" " + integer + " doz " + contentTypesEnum.toString()));
            message.append(" içermektedir. Afiyet Olsun.");
            System.out.println(message);

        }
    }

    private static boolean checkAllStatements() {
        Boolean isCupReady = true;
        Boolean isWaterEnought = true;
        Boolean isCoffeeEnought = true;

        return (isCupReady ? (isWaterEnought ? isCoffeeEnought ? true : false : false) : false);
    }

}
