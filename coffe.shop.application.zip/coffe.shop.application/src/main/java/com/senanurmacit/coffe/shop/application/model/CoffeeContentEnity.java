package com.senanurmacit.coffe.shop.application.model;

import lombok.Data;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "T_COFFEE_CONTENT_ENTITY")
@Data
public class CoffeeContentEnity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "COFFEE_NAME", nullable = false)
    private String coffeeName;

    @Column(name = "COFFEE_NUMBER", nullable = false)
    private Integer coffeeNumber;

    @OneToMany(mappedBy="coffeeContentEnity")
    private Set<CoffeePriceEntity> coffeePriceEntitySet;


}
