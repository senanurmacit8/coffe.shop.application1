package com.senanurmacit.coffe.shop.application.config;

import com.senanurmacit.coffe.shop.application.controller.impl.CoffeeOrderRestControllerImpl;
import org.springframework.context.annotation.Bean;

@org.springframework.context.annotation.Configuration
public class AppConfiguration {

    @Bean
    public CoffeeOrderRestControllerImpl coffeeOrderRestController() {
        return new CoffeeOrderRestControllerImpl();
    }

}
