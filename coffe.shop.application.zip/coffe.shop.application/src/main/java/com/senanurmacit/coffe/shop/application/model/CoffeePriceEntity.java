package com.senanurmacit.coffe.shop.application.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "T_COFFEEE_PRICE")
@Data
public class CoffeePriceEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "COFFEE_NAME", nullable = false)
    private String coffee_name;

    @Column(name = "COFFEE_PRICE", nullable = false)
    private String coffee_price;

    @ManyToOne
    @JoinColumn(name="id", nullable=false)
    private CoffeeContentEnity coffeeContentEnity;
}
