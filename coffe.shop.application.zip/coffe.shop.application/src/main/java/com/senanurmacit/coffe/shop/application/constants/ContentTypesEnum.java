package com.senanurmacit.coffe.shop.application.constants;

public enum ContentTypesEnum {

    ESPRESSO,
    DOUBLE_ESPRESSO,
    CAPPUCCINO,
    CAFFE_LATTE,
    MOCHA,
    AMERICANO,
    HOT_WATER,
    STEAMED_MILK,
    MILK_FOAM,
    HOT_CHOCOLATE,
}
