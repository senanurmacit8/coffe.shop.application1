package com.senanurmacit.coffe.shop.application.dto.coffee;

import com.senanurmacit.coffe.shop.application.constants.ContentTypesEnum;
import lombok.Data;

import java.util.Map;

@Data
public class CoffeePriceDTO  {
    String CoffeeName;
    Double price;
    Map<ContentTypesEnum,Integer> content;
    String status;
}
