package com.senanurmacit.coffe.shop.application.controller;

public interface CoffeeOrderRestController {


}
