package com.senanurmacit.coffe.shop.application.service;

import java.util.List;

public interface CoffeeOrderService {

     List<String> getAllCoffeeTypes();
}
